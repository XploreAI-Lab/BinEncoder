import os
# import test



# IDA Path
IDA32_DIR = "D:\\ida\\ida.exe"
IDA64_DIR = "D:\\ida\\ida64.exe"
ROOT_DIR = os.path.dirname(os.path.realpath(__file__))
JSON_DIR = ROOT_DIR + os.sep + 'datasets'

